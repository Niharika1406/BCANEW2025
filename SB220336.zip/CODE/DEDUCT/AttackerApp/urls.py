from django.urls import path
from django.conf.urls.static import static
import os
from .views import *
from django.conf import settings



urlpatterns = [
    path("attackerlogin/", attackerlogin, name="attackerlogin"),
    path("attckerhome/", attckerhome, name="attckerhome"),
    path("searchfiles/", searchfiles, name="searchfiles"),
    path("attackfiles/<int:id>/", attackfiles, name="attackfiles"),


]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)