from django.shortcuts import render,redirect, get_object_or_404
from OwnerApp.models import *
from django.contrib import messages
from django.core.paginator import Paginator

# Create your views here.


def attackerlogin(request):
    if request.method=="POST":
        attackeremail = request.POST['attackeremail']
        attackerpassword = request.POST['attackerpassword']
        if attackeremail == "attacker@gmail.com" and attackerpassword =="attacker":
            request.session['attackeremail'] = attackeremail
            print(5555555555555555555)
            return redirect('attckerhome')
        else:
            # messages.add_message(request,messages.WARNING,"Invalid Credentials")
            messages.error(request, "Invalid user Credentials or Cloud Not Verified Yet")
            return redirect('attackerlogin')  # Redirect after setting the message
    return render(request,"attackerlogin.html")

def attckerhome(req):
    return render(req,"attckerhome.html")
def searchfiles(req):
    is_search = False
    page_number = req.GET.get('page')  # Get current page number from the request

    if req.method == "POST":
        search = req.POST.get('search', '')
        data = OwnerUploadData.objects.filter(filename__icontains=search)
        is_search = True
        if data.exists():
            # Pagination for search results
            paginator = Paginator(data, 5)  # Display 5 files per page
            page_data = paginator.get_page(page_number)
            return render(req, "searchfiles.html", {'search': search, 'data': page_data, 'is_search': is_search})
        else:
            msg = "No File Found With Matching Filename"
            return render(req, "searchfiles.html", {'search': search, 'msg': msg, 'is_search': is_search})

    # If no search, display all files with pagination
    all_data = OwnerUploadData.objects.all()
    paginator = Paginator(all_data, 5)  # Display 5 files per page
    page_data = paginator.get_page(page_number)

    return render(req, "searchfiles.html", {'data': page_data, 'is_search': is_search})
    

def attackfiles(req, id):
    # Fetch the specific OwnerUploadData object by id
    data = get_object_or_404(OwnerUploadData, id=id)

    # Update the status attribute
    data.status = 'attacked'
    # Save the updated object
    data.save()

    msg = "File Attacked Successfully"
    return render(req, 'searchfiles.html', {'msg': msg})

    