from django.urls import path
from django.conf.urls.static import static
import os
from .views import *
from django.conf import settings



urlpatterns = [
    path("cloudhome/",cloudhome, name="cloudhome"),
    path("cloudlogin/", cloudlogin, name="cloudlogin"),
    path("View_Owners/", View_Owners, name="View_Owners"),
    path("View_Users/", View_Users, name="View_Users"),
    path("acceptowners/<int:id>/", acceptowners, name="acceptowners"),
    path("rejectowners/<int:id>/", rejectowners, name="rejectowners"),
    path("acceptusers/<int:id>/", acceptusers, name="acceptusers"),
    path("rejectusers/<int:id>/", rejectusers, name="rejectusers"),
    path("View_Owner_Files/", View_Owner_Files, name="View_Owner_Files"),
    path("key_data/<int:id>/", key_data, name="key_data"),
    path("OwnerData/<int:id>/", OwnerData, name="OwnerData"),
    path("viewaattackedfiles/", viewaattackedfiles, name="viewaattackedfiles"),
    path("viewarecoveredfiles/", viewarecoveredfiles, name="viewarecoveredfiles"),
    path("viewfilesgraph/", viewfilesgraph, name="viewfilesgraph"),
    path('download/', download_decrypted_file, name='download_decrypted_file'),

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)