from django.shortcuts import render,redirect
from OwnerApp.models import *
from django.contrib import messages
from django.core.mail import send_mail
import secrets
import string
import random
from django.conf import settings
from UserApp.models import *
from OwnerApp.aes import *
from django.http import HttpResponse

# Create your views here.


def cloudlogin(request):
    if request.method=="POST":
        cloudemail = request.POST['cloudemail']
        cloudpassword = request.POST['cloudpassword']
        if cloudemail == "cloud@gmail.com" and cloudpassword =="cloud":
            request.session['cloudemail'] = cloudemail
            print(5555555555555555555)
            return redirect('cloudhome')
        else:
            # messages.add_message(request,messages.WARNING,"Invalid Credentials")
            messages.error(request,"Invalid Credentials")
            return redirect('cloudlogin')
    return render(request,"cloudlogin.html")


def cloudhome(req):
     return render(req,'cloudhome.html' ,{'success': True})

def View_Owners(req):
    # College_Registration_Model.objects.all().delete()
    success= "Sent The Accepted Status To The User"
    fail= "Sent The Rejected Status To The User"
    data= OwnerRegistration.objects.filter(status='pending')
    return render(req, 'Authorize_Owners.html', {"data" : data})

def View_Users(req):
    # College_Registration_Model.objects.all().delete()
    success= "Sent The Accepted Status To The User"
    fail= "Sent The Rejected Status To The User"
    data= UserRegistration.objects.filter(status='pending')
    return render(req, 'Authorize_Users.html', {"data" : data})


def acceptowners(request, id):
    update = OwnerRegistration.objects.get(id=id)
    update.status = "active"
    email = update.owneremail
    update.save()
    message = f'Hi {email},\n\nYour DEDUCT Project Login is now active. You can login now.\n\nThis message is automatically generated, so please do not reply to this email.\n\nThank you.\n\nRegards,\nAdmin'
    subject = "DEDUCT Login Active"
    email_from = settings.EMAIL_HOST_USER
    recipient_list = [email]
    send_mail(subject, message, email_from, recipient_list, fail_silently=False)
    # success= "Sent The Accepted Status To The User"
    # messages.success(request,"Sent The Accepted Status To The User")
    return redirect('View_Owners')

def rejectowners(request, id):
    update = OwnerRegistration.objects.get(id=id)
    update.status = "rejected"
    email = update.owneremail
    update.save()
    message = f'Hi {email},\n\nYour DEDUCT Project failed to activate. You can contact support for further assistance.\n\nThis message is automatically generated, so please do not reply to this email.\n\nThank you.\n\nRegards,\nAdmin'
    subject = "DEDUCT Login Failed or Rejected"
    email_from = settings.EMAIL_HOST_USER
    recipient_list = [email]
    send_mail(subject, message, email_from, recipient_list, fail_silently=False)
    # fail= "Sent The Rejected Status To The User"
    # messages.success(request,"Sent The Rejected Status To The User")
    return redirect('View_Owners')


def acceptusers(request, id):
    update = UserRegistration.objects.get(id=id)
    update.status = "active"
    email = update.useremail
    update.save()
    message = f'Hi {email},\n\nYour DEDUCT Project Login is now active. You can login now.\n\nThis message is automatically generated, so please do not reply to this email.\n\nThank you.\n\nRegards,\nAdmin'
    subject = "DEDUCT Login Active"
    email_from = settings.EMAIL_HOST_USER
    recipient_list = [email]
    send_mail(subject, message, email_from, recipient_list, fail_silently=False)
    # success= "Sent The Accepted Status To The User"
    return redirect('View_Users')

def rejectusers(request, id):
    update = UserRegistration.objects.get(id=id)
    update.status = "rejected"
    email = update.useremail
    update.save()
    message = f'Hi {email},\n\nYour DEDUCT Project failed to activate. You can contact support for further assistance.\n\nThis message is automatically generated, so please do not reply to this email.\n\nThank you.\n\nRegards,\nAdmin'
    subject = "DEDUCT Login Failed or Rejected"
    email_from = settings.EMAIL_HOST_USER
    recipient_list = [email]
    send_mail(subject, message, email_from, recipient_list, fail_silently=False)
    # fail= "Sent The Rejected Status To The User"
    return redirect('View_Users')


def View_Owner_Files(req):
    # College_Registration_Model.objects.all().delete()
    data= OwnerUploadData.objects.all()
    if data:
        return render(req, 'View_OwnerFiles.html', {"data" : data})
    else:
        msg= "Now Data Found Uploaded By Owners"
        return render(req, 'View_OwnerFiles.html', {"msg" : msg})


def key_data(req,id):
    Owneremail = req.session['Owneremail']
    data= OwnerUploadData.objects.all()
    if req.method=="POST":
        key = req.POST.get('key')
        data = OwnerUploadData.objects.filter(owneremail=Owneremail,random_password=key)
        if data:
            return redirect('OwnerData', id=id)
        else:
            msg= "No Data Found With This Key"
            return render(req, 'View_OwnerFiles.html', {"msg" : msg, 'data':data})
    
    return render(req, 'key_data.html', {"id": id})


def OwnerData(req, id):
    Owneremail = req.session.get('Owneremail')  # Use .get() to safely access session data
    print(Owneremail)
    
    try:
        data = OwnerUploadData.objects.get(owneremail=Owneremail, id=id)
    except OwnerUploadData.DoesNotExist:
        # Handle the case where no matching record is found
        # For example, return an HttpResponse or redirect to an error page
        return HttpResponse("Record not found or access denied")
    
    encrypted_content = data.file.read()
    key = data.key
    iv = data.iv
    tag = data.tag

    # Decrypt the content
    decrypted_content = decrypt_file(key, iv, tag, encrypted_content)

    return render(req, 'OwnerData.html', {"id": id, "decrypted_content": decrypted_content.decode('utf-8')})

def download_decrypted_file(req):
    decrypted_file = req.session.get('decrypted_file')
    if decrypted_file:
        response = HttpResponse(decrypted_file, content_type='application/octet-stream')
        response['Content-Disposition'] = 'attachment; filename="decrypted_data.txt"'
        return response
    else:
        return HttpResponse("No decrypted data available for download.")


def viewaattackedfiles(req):
    owner = OwnerUploadData.objects.filter(status='attacked')  # Fetch the
    return render(req, 'viewaattackedfiles.html', {'data':owner} )


def viewarecoveredfiles(req):
    owner = OwnerUploadData.objects.filter(status='safe')  # Fetch the
    return render(req, 'viewarecoveredfiles.html', {'data':owner} )

def viewfilesgraph(req):
    data = OwnerUploadData.objects.all()
    context={
        "data":data,
    }
    return render(req, 'viewfilesgraph.html', context)