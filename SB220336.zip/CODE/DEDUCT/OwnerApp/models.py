from django.db import models

# Create your models here.



class OwnerRegistration(models.Model):
    ownername=models.CharField(max_length=100, null=True)
    owneremail=models.EmailField(max_length=50,null=True)
    ownerpasscode= models.CharField(max_length=10)
    ownercontact= models.CharField(max_length=100, null=True)
    owneraddress= models.CharField(max_length=100, null=True)
    status= models.CharField(max_length=20,default='pending')
    class Meta:
        db_table="OwnerRegistration"    



class OwnerUploadData(models.Model):
    owneremail= models.CharField(max_length=50, null=True)
    ownername = models.CharField(max_length=100, null=True)
    filename = models.CharField(max_length=255, null=True)
    file = models.FileField(upload_to="encrypted_ownerfiles/%y", null=True)
    normalfiles = models.FileField(upload_to="normalfiles/%y", null=True)
    status= models.CharField(max_length=50, default= "pending", null=True)
    # Fields for encryption
    key = models.BinaryField(max_length=255,null=True)  # Store key as binary data
    salt = models.CharField(max_length=255,null=True)
    iv = models.BinaryField(max_length=255,null=True)
    tag = models.BinaryField(max_length=255,null=True)
    random_password = models.CharField(max_length=255,null=True)
    file_hash=models.CharField(max_length=1000,null=True)

    class Meta:
        db_table = "OwnerUploadData"