# # Encryption and Decryption
# from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
# from cryptography.hazmat.primitives import hashes
# from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
# from cryptography.hazmat.backends import default_backend
# from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
# import os
# from base64 import urlsafe_b64encode
# from django.core.files.base import ContentFile
# from django.core.files.base import ContentFile

# # Create your views here.
# def generate_key():
#     backend = default_backend()
#     salt = os.urandom(16)
#     kdf = Scrypt(salt=salt, length=32, n=2**14, r=8, p=1, backend=backend)
#     key = kdf.derive(b"some_password")
#     return key, salt

# def encrypt_file(key, file_data):
#     iv = os.urandom(12)
#     cipher = Cipher(algorithms.AES(key), modes.GCM(iv), backend=default_backend())
#     encryptor = cipher.encryptor()
#     ciphertext = encryptor.update(file_data) + encryptor.finalize()
#     return (ciphertext, iv, encryptor.tag)

# def decrypt_file(key, iv, tag, ciphertext):
#     cipher = Cipher(algorithms.AES(key), modes.GCM(iv, tag), backend=default_backend())
#     decryptor = cipher.decryptor()
#     return decryptor.update(ciphertext) + decryptor.finalize()





from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
import os
import hashlib
import string
import secrets
from base64 import urlsafe_b64encode
from django.core.files.base import ContentFile
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import OwnerUploadData  # Assuming this is your model

# Encryption utility functions
def generate_key():
    backend = default_backend()
    salt = os.urandom(16)
    kdf = Scrypt(salt=salt, length=32, n=2**14, r=8, p=1, backend=backend)
    key = kdf.derive(b"some_password")
    return key, salt

def encrypt_file(key, file_data):
    iv = os.urandom(12)
    cipher = Cipher(algorithms.AES(key), modes.GCM(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(file_data) + encryptor.finalize()
    return (ciphertext, iv, encryptor.tag)

def decrypt_file(key, iv, tag, ciphertext):
    cipher = Cipher(algorithms.AES(key), modes.GCM(iv, tag), backend=default_backend())
    decryptor = cipher.decryptor()
    return decryptor.update(ciphertext) + decryptor.finalize()
