from django.shortcuts import render, redirect,get_object_or_404
from .models import *
from django.contrib import messages
from django.core.mail import send_mail
import secrets
import string
import random
from django.conf import settings
from .aes import *
from UserApp.models import *
from django.http import HttpResponse
import hashlib
from django.core.paginator import Paginator

# Create your views here.


def index(req):
    return render(req, 'index.html')

def Owner_Registration(req):
    # OwnerRegistration.objects.all().delete()
    if req.method =="POST":
        ownername = req.POST['ownername']
        owneremail = req.POST['owneremail']
        ownerpasscode = req.POST['ownerpasscode']
        confpasscode = req.POST['confpasscode']
        ownercontact = req.POST['ownercontact']
        owneraddress = req.POST['owneraddress']
        data = OwnerRegistration.objects.filter(owneremail=owneremail).exists()
        if OwnerRegistration.objects.filter(owneremail=owneremail).exists():
            msg= "This email address is already exists, try with another email"
            return render(req, 'Owner_Registration.html', {'msg': msg})
        elif ownerpasscode != confpasscode:
            msg= "Password and confirm password does not match"
            return render(req, 'Owner_Registration.html', {'msg': msg})
        Owner_data = OwnerRegistration(ownername=ownername, owneremail=owneremail, ownerpasscode=ownerpasscode, ownercontact=ownercontact, owneraddress=owneraddress)
        Owner_data.save()
        # Sending credentials through email
        email_subject = f'{ownername} Registration Successfull'
        email_message = f'Hello {ownername},\n\nThank you for registering with us!\n\nHere are your Login details:\n\nUser Email: {owneremail}\nPassword: {ownerpasscode}\n\nPlease keep this information safe.\n\nBest regards,\nYour Website Team'
        send_mail(email_subject, email_message, 'appcloud887@gmail.com', [owneremail])
        update_password = OwnerRegistration.objects.get(owneremail=owneremail)
        update_password.passcode = ownerpasscode
        update_password.save()
        return render(req,'Owner_login.html',{'success': True} )
    
    return render(req, 'Owner_registration.html')

def Owner_Login(request):
    if request.method == "POST":
        Owneremail = request.POST.get('Owneremail')
        Passcode = request.POST.get('Passcode')        
        owners = OwnerRegistration.objects.filter(owneremail=Owneremail, ownerpasscode=Passcode, status='active')
        
        if owners.exists(): 
            owner = owners.first()  # Take the first match
            # Check if the password matches
            if owner.ownerpasscode == Passcode:
                # Password matches, set the session
                request.session['Ownername'] = owner.ownername
                request.session['Owneremail'] = owner.owneremail
                return redirect('Ownerhome') 
            else:
                messages.error(request, "Invalid Owner Credentials or Cloud Not Verified Yet")
                return redirect('Owner_Login')
        else:
            messages.error(request,"User not found or not active. Please register or wait for Cloud approval.")
            return redirect('Owner_Login')
        
    return render(request, "Owner_Login.html")



def Ownerhome(req):
    ownername= req.session['Ownername']
    return render(req, 'Ownerhome.html', {'ownername':ownername})


def is_duplicate(file_hash,owneremail):
    print(55555555555555555,owneremail)
    return OwnerUploadData.objects.filter(file_hash=file_hash,owneremail=owneremail).exists()

# Backend view function
def Upload_Files(req):
    owners = OwnerUploadData.objects.all()

    if req.method == "POST":
        owneremail = req.session.get('Owneremail')
        ownername = req.session.get('Ownername')
        filename = req.POST.get('filename')
        filedata = req.FILES.get('file')

        # Ensure file is read once
        readdata = filedata.read()

        # Generate key and salt
        key, salt = generate_key()

        # Generating a random password
        length = 4
        characters = string.digits
        random_password = ''.join(secrets.choice(characters) for _ in range(length))

        # Hash the file to check for duplicates
        file_hash = hashlib.sha256(readdata).hexdigest()

        if is_duplicate(file_hash, owneremail):  # Assuming is_duplicate is implemented
            messages.error(req, f" '{filedata}', File Content already existed! ")
            return redirect('Upload_Files')

        # Encrypt the file data
        encrypted_data, iv, tag = encrypt_file(key, readdata)  # Use readdata (read once)

        # Save encrypted file as ContentFile
        encrypted_file = ContentFile(encrypted_data, name=filename)

        # Create and save OwnerUploadData instance
        upload = OwnerUploadData(
            file_hash=file_hash,
            owneremail=owneremail,
            ownername=ownername,
            filename=filename,
            normalfiles=filedata,
            file=encrypted_file,  # Store the encrypted file
            key=key,
            salt=salt,
            iv=iv,
            tag=tag,
            random_password=random_password
        )
        upload.save()

        messages.success(req, f"{filename} file uploaded with encryption successfully")
        return redirect("Upload_Files")

    return render(req, 'Upload_Files.html')


def User_File_Request(req):
    Owneremail = req.session['Owneremail']
    # Fetch data requested by users
    data = UserRequest.objects.filter(owneremail=Owneremail, status='requested')
    
    # Paginate the results (4 items per page)
    paginator = Paginator(data, 4)
    page_number = req.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    if data:
        return render(req, 'User_File_Request.html', {"page_obj": page_obj})
    else:
        msg = "No Data Found Requested By Users"
        return render(req, 'User_File_Request.html', {"msg": msg})
    
def acceptrequest(request, id):
    try:
        Owneremail = request.session['Owneremail']
        owner = OwnerUploadData.objects.filter(owneremail=Owneremail).first()  # Fetch the first matching OwnerUploadData object
        if owner:
            decryptkey = owner.random_password  # Assuming 'random_password' is a field in OwnerUploadData
            update = get_object_or_404(UserRequest, id=id)
            update.status = "active"
            email = update.useremail
            update.save()

            message = f'Hi {email},\n\nYour DEDUCT Project File Requested Accepted By Your Owner Now You can Access The File Using Decryption Key.\n\n Decryption Key:{decryptkey} .\n\nThis message is automatically generated, so please do not reply to this email.\n\nThank you.\n\nRegards,\nAdmin'
            subject = "DEDUCT Login Active"
            email_from = settings.EMAIL_HOST_USER
            recipient_list = [email]
            send_mail(subject, message, email_from, recipient_list, fail_silently=False)
            messages.success(request,"File Accepted Successfully")
            return redirect('User_File_Request')
        else:
            # Handle case where no matching OwnerUploadData is found
            return HttpResponse('Owner Upload Data not found for this email.')

    except KeyError:
        # Handle case where 'Owneremail' is not found in session
        return HttpResponse('Owneremail not found in session.')

    except Exception as e:
        # Handle other exceptions gracefully
        return HttpResponse(f'Error: {e}')

def rejectrequest(request, id):
    update = UserRequest.objects.get(id=id)
    update.status = "rejected"
    email = update.useremail
    update.save()
    message = f'Hi {email},\n\nYour DEDUCT Project File Requested Rejected By Your Owner. Pls contact to your Admin or Data Owner. You can contact support for further assistance.\n\nThis message is automatically generated, so please do not reply to this email.\n\nThank you.\n\nRegards,\nAdmin'
    subject = "DEDUCT Login Failed or Rejected"
    email_from = settings.EMAIL_HOST_USER
    recipient_list = [email]
    send_mail(subject, message, email_from, recipient_list, fail_silently=False)
    messages.error(request,"Rejected Successfully")
    return redirect('User_File_Request')


def viewunsafefiles(req):
    Owneremail = req.session['Owneremail']
    owner = OwnerUploadData.objects.filter(owneremail=Owneremail, status='attacked')  # Fetch the
    return render(req, 'viewunsafefiles.html', {'data':owner} )

def recoverfiles(req,id):
    Owneremail = req.session['Owneremail']
    owner =  get_object_or_404(OwnerUploadData, owneremail=Owneremail, id=id)  # Fetch the
    owner.status = "safe"
    owner.save()
    msg = "File Recovered Successfully"
    return render(req, 'viewunsafefiles.html', {'recoverfiles':owner, 'msg':msg, 'id':id} )

