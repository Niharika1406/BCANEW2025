from django.urls import path
from django.conf.urls.static import static
import os
from .views import *
from django.conf import settings



urlpatterns = [
    path("", index, name="index"),
    path("Owner_Registration/", Owner_Registration, name="Owner_Registration"),
    path("Owner_Login/", Owner_Login, name="Owner_Login"),
    path("Ownerhome/", Ownerhome, name="Ownerhome"),
    path("Upload_Files/", Upload_Files, name="Upload_Files"),
    path("User_File_Request/", User_File_Request, name="User_File_Request"),
    path("acceptrequest/<int:id>/", acceptrequest, name="acceptrequest"),
    path("rejectrequest/<int:id>/", rejectrequest, name="rejectrequest"),
    path("viewunsafefiles/", viewunsafefiles, name="viewunsafefiles"),
    path("recoverfiles/<int:id>/", recoverfiles, name="recoverfiles"),



]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)