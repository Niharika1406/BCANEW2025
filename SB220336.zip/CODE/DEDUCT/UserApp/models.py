from django.db import models

# Create your models here.



class UserRegistration(models.Model):
    username=models.CharField(max_length=100, null=True)
    useremail=models.EmailField(max_length=50,null=True)
    userpasscode= models.CharField(max_length=10)
    usercontact= models.CharField(max_length=100, null=True)
    useraddress= models.CharField(max_length=100, null=True)
    status= models.CharField(max_length=20,default='pending')
    class Meta:
        db_table="UserRegistration"    


class UserRequest(models.Model):
    username=models.CharField(max_length=100, null=True)
    useremail=models.EmailField(max_length=50,null=True)
    ownername= models.CharField(max_length=10)
    owneremail= models.CharField(max_length=100, null=True)
    filename= models.CharField(max_length=100, null=True)
    status= models.CharField(max_length=20,default='pending')

    class Meta:
        db_table="UserRequest" 

