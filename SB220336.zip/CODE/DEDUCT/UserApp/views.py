from django.shortcuts import render,redirect,get_object_or_404

# Create your views here.

from .models import *
from django.contrib import messages
from django.core.mail import send_mail
import secrets
import string
import random
from django.conf import settings
from OwnerApp.models import *
from OwnerApp.aes import *
from django.http import HttpResponse



def User_Registration(req):
    # userRegistration.objects.all().delete()
    if req.method =="POST":
        username = req.POST['username']
        useremail = req.POST['useremail']
        userpasscode = req.POST['userpasscode']
        confpasscode = req.POST['confpasscode']
        usercontact = req.POST['usercontact']
        useraddress = req.POST['useraddress']
        data = UserRegistration.objects.filter(useremail=useremail).exists()
        if UserRegistration.objects.filter(useremail=useremail).exists():
            msg= "This email address is already exists, try with another email"
            return render(req, 'user_Registration.html', {'msg': msg})
        elif userpasscode != confpasscode:
            msg= "Password and confirm password does not match"
            return render(req, 'user_Registration.html', {'msg': msg})
        user_data = UserRegistration(username=username, useremail=useremail, userpasscode=userpasscode, usercontact=usercontact, useraddress=useraddress)
        user_data.save()
        # Sending credentials through email
        email_subject = f'{username} Registration Successfull'
        email_message = f'Hello {username},\n\nThank you for registering with us!\n\nHere are your Login details:\n\nUser Email: {useremail}\nPassword: {userpasscode}\n\nPlease keep this information safe.\n\nBest regards,\nYour Website Team'
        send_mail(email_subject, email_message, 'appcloud887@gmail.com', [useremail])
        update_password = UserRegistration.objects.get(useremail=useremail)
        update_password.passcode = userpasscode
        update_password.save()
        return render(req,'user_login.html',{'success': True} )
    
    return render(req, 'user_registration.html')

def userhome(req):
    username=req.session['username']
    return render(req, 'user_home.html',{'username':username})

from django.contrib import messages
from django.shortcuts import render, redirect

def User_Login(request):
    if request.method == "POST":
        useremail = request.POST.get('useremail')
        Passcode = request.POST.get('Passcode')
        
        users = UserRegistration.objects.filter(useremail=useremail, userpasscode=Passcode, status='active')
        
        if users.exists(): 
            user = users.first()  # Take the first match
            # Check if the password matches
            if user.userpasscode == Passcode:
                # Password matches, set the session
                request.session['username'] = user.username
                request.session['useremail'] = user.useremail
                return redirect('userhome')
            else:
                messages.error(request, "Invalid user Credentials or Cloud Not Verified Yet")
                return redirect('User_Login')  # Redirect after setting the message
        else:
            messages.error(request, "User not found or not active. Please register or wait for Cloud approval.")
            return redirect('User_Login')  # Redirect after setting the message
    
    # On GET request, render the login page without error messages
    return render(request, "user_Login.html")


def View_Files(req):
    data = OwnerUploadData.objects.all()
    if data:
        return render(req, 'View_Files.html', {"data": data})
    else:
        msg = "No Data Found Uploaded By Owners"
        return render(req, 'View_Files.html', {"msg": msg})
    

def Send_Request(req, id):
    # Retrieve the OwnerUploadData object based on id
    data = get_object_or_404(OwnerUploadData, id=id)
    
    if req.method == "POST":
        try:
            Owneremail = req.POST.get('Owneremail')
            # Assuming 'filename' is retrieved correctly from the form or from data object
            filename = data.filename
        except:
            return render(req, 'Send_Request.html', {'id': id, 'data': data, 'error': "Owner email is required." })
        
        # Retrieve session variables
        username = req.session.get('username')
        useremail = req.session.get('useremail')
        Ownername = req.session.get('Ownername')
        
        # Save the UserRequest object
        saveto = UserRequest(username=username, useremail=useremail, ownername=Ownername, owneremail=Owneremail, filename=filename)
        saveto.save()
        
        # Update status if 'status' is a field in UserRequest model
        saveto.status = 'requested'
        saveto.save()
        messages.success(req,f"'{filename}' file request sent to '{Owneremail}' owner successfully")
        
        return render(req, 'Send_Request.html', {'id': id, 'data': data})
    
    # If GET request, render the view files page
    return render(req, 'Send_Request.html', {'id': id, 'data': data})


def View_Responce(req):
    # College_Registration_Model.objects.all().delete()
    useremail=req.session.get('useremail')
    print(useremail,888888888888888888)
    filedata=OwnerUploadData.objects.all()
    data= UserRequest.objects.filter(useremail=useremail, status='active')
    if data:
        return render(req, 'View_Responce.html', {"data" : filedata, })
    else:
        messages.error(req,"No Data Found")
        return render(req, 'View_Responce.html')


def decrypt_key(req,id):
    useremail=req.session.get('useremail')
    data= OwnerUploadData.objects.all()
    if req.method=="POST":
        key = req.POST.get('key')
        data = OwnerUploadData.objects.filter(random_password=key)
        if data:
            return redirect('Filedata', id=id)
        else:   
            msg= "No Data Found With This Key"
            return render(req, 'View_Responce.html', {"msg" : msg, 'data':data})
    
    return render(req, 'decrypt_key.html', {"id": id})


def Filedata(req, id):
    useremail = req.session.get('useremail')  # Use .get() to safely access session data
    print(useremail)
    try:
        data = OwnerUploadData.objects.get(id=id)
    except OwnerUploadData.DoesNotExist:
        # Handle the case where no matching record is found
        # For example, return an HttpResponse or redirect to an error page
        return HttpResponse("Record not found or access denied")
    
    encrypted_content = data.file.read()
    key = data.key
    iv = data.iv
    tag = data.tag
    decrypted_content = decrypt_file(key, iv, tag, encrypted_content)
    print('Decrypted data:',decrypted_content)
    decrypted_content = decrypted_content.decode()

    return render(req, 'Filedata.html', {"id": id, "decrypted_content": decrypted_content})


def download_decrypted_file(req, id):
    try:
        data = OwnerUploadData.objects.get(id=id)
    except OwnerUploadData.DoesNotExist:
        return HttpResponse("Record not found or access denied")
    
    encrypted_content = data.file.read()
    key = data.key
    iv = data.iv
    tag = data.tag

    # Decrypt the content
    decrypted_content = decrypt_file(key, iv, tag, encrypted_content)
    
    if decrypted_content:
        response = HttpResponse(decrypted_content, content_type='application/octet-stream')
        response['Content-Disposition'] = f'attachment; filename="decrypted_data_{id}.txt"'
        return response
    else:
        return HttpResponse("No decrypted data available for download.")