from django.urls import path
from django.conf.urls.static import static
import os
from .views import *
from django.conf import settings



urlpatterns = [
    path("User_Registration/", User_Registration, name="User_Registration"),
    path("User_Login/", User_Login, name="User_Login"),
    path("userhome/", userhome, name="userhome"),
    path("View_Files/", View_Files, name="View_Files"),
    path("View_Responce/", View_Responce, name="View_Responce"),
    path("Send_Request/<int:id>/", Send_Request, name="Send_Request"),
    path("decrypt_key/<int:id>/", decrypt_key, name="decrypt_key"),
    path("Filedata/<int:id>/", Filedata, name="Filedata"),
    path('download/<int:id>/', download_decrypted_file, name='download_decrypted_file'),


]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)